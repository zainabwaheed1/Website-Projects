#{{uc_id}} .{{item.item_repeater_class}} .ue-hover-image-video{
  background:url("{{item.image}}");
}