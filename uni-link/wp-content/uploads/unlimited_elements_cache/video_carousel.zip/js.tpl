{{ ucfunc("put_docready_start") }}

    var objWidget = jQuery('#{{uc_id}}');

    {% if carousel_type == "owl" %}
    // --- Carousel type: Owl ---
    
      function initCarousel() {
        objWidget.owlCarousel({
            setActiveClassOnMobile: {{active_on_mobile}},
            loop: {{loop}},
            center: {{center}},
            rtl: {{rtl}},
            autoplay: {{autoplay}},
            autoplayHoverPause: {{autoplayhoverpause}},
            navText: [
                "<i class='{{left_arrow}}'></i>",
                "<i class='{{right_arrow}}'></i>"
            ],
            changeItemOnClick: {{scroll_on_click}},
            rewindNav: false,
            autoplayTimeout: {{autoplay_interval}},
            smartSpeed: {{transition_speed}},
            dots: {{show_dots}},
            {% if show_dots == "true" %}dotsEach: {{dot_each_item}},{% endif %}
            scrollToHead: {{scroll_to_head}},
            scrollToHeadOffset: {{scroll_to_head_offset}},
            paddingType: "{{stage_padding_type}}",
            mouseDrag: {{mouse_drag}},
            touchDrag: {{touch_drag}},
            mousewheelControl: {{enable_mouse_wheel_control}},
            responsive: {
                0: {
                    items: {{number_of_items_mobile}},
                    slideBy: {{slides_to_scroll_mobile}},
                    nav: {{show_arrows_mobile}},
                    scrollToHeadForceOnMobile: {{scroll_to_head_forced_on_mobile}},
                    margin: {{margin_between_slides_mobile}},
                    {% if stage_padding_type != "none" %}stagePadding: {{stagepadding_mobile}},{% endif %}
                },
                768: {
                    items: {{number_of_items_tablet}},
                    slideBy: {{slides_to_scroll_tablet}},
                    nav: {{show_arrows_tablet}},
                    margin: {{margin_between_slides_tablet}},
                    {% if stage_padding_type != "none" %}stagePadding: {{stagepadding_tablet}},{% endif %}
                },
                980: {
                    items: {{number_of_items}},
                    slideBy: {{slides_to_scroll}},
                    nav: {{show_arrows}},
                    margin: {{margin_between_slides}},
                    {% if stage_padding_type != "none" %}stagePadding: {{stagepadding}},{% endif %}
                }
            }
        });

        setTimeout(function () {
            UEVideoHoverWidget(objWidget);
        }, 200);
      }

      initCarousel();

      objWidget.on("uc_ajax_refreshed", function () {
          objWidget.trigger('destroy.owl.carousel');
          initCarousel();
      });

      {{ ucfunc("put_remote_parent_js","objWidget") }}
     
    // --- End Carousel type: Owl ---
    {% endif %}
      
    {% if carousel_type == "marquee" %}
    // --- Carousel type: Marquee ---
      var objMarquee = objWidget.find('.uc_marquee');

      function initMarqueeWithVideos() {
          UCTestimonialMarquee(objMarquee);

          setTimeout(function () {
              UEVideoHoverWidget(objWidget);
          }, 400);
      }

      setTimeout(initMarqueeWithVideos, 200);

      objWidget.on("uc_ajax_refreshed", function () {
          initMarqueeWithVideos();
      });
    // --- End Carousel type: Marquee ---
    {% endif %}

    {% if show_lightbox == "true" %}
      // UEVideoLightbox('#{{uc_id}}-lightbox');
    {% endif %}


{{ ucfunc("put_docready_end") }}