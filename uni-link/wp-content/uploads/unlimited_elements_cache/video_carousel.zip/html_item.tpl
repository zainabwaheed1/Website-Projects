<div class="ue_vc_item ue-item  {% if carousel_type == "marquee" %}uc_video_marquee_holder{% endif %} {{item.item_repeater_class}}"
     {% if carousel_type == "marquee" %}style="width:0px;"{% endif %}
     {% if show_lightbox == "true" %}
       {% if item.video_source == "html5video" %}
         href="{% if item.video_url is not empty %}{{item.video_url}}{% else %}{{uc_assets_url}}/demo-video.mp4{% endif %}" data-lity
       {% elseif item.video_source == "vimeo" %}
         href="https://vimeo.com/{{ item.vimeo_video_id|ucsafe|raw }}" data-lity
       {% endif %}
     {% endif %}
     >
    
    <div id="{{item.item_id}}" class="ue-hover-image-video">
      
      {% if item.image is not empty %}<img class="ue-image" src="{{item.image}}" alt="{{item.image_alt}}" {{item.image_attributes|ucsafe|raw}}>{% else %}<div class="ue-image"></div>{% endif %}
      
      {% if item.video_source == "html5video" %}
        <video class="ue-video" preload="metadata" muted playsinline loop>
          <source src="{% if item.video_url is not empty %}{{item.video_url}}{% else %}{{uc_assets_url}}/demo-video.mp4{% endif %}" type="video/mp4" />
        </video>
      {% endif %}

      {% if item.video_source == "vimeo" %}
        <iframe class="ue-video"
                src="https://player.vimeo.com/video/{{item.vimeo_video_id|ucsafe|raw}}?background=1&autoplay=1&muted=1&loop=1&title=0&byline=0&portrait=0"
                frameborder="0"
                allow="autoplay; fullscreen">
        </iframe>
      {% endif %}

      {% if show_overlay == "true" %}
        <div class="ue-overlay">
          {% if show_overlay_icon == "true" %}
            <span class="ue-overlay-icon" role="img" aria-hidden="true">
              {% if item.show_custom_overlay_icon == "true" %}
                {{item.custom_overlay_icon_html|ucsafe|raw}}
              {% else %}
                {{overlay_icon_html|ucsafe|raw}}
              {% endif %}
            </span>
          {% endif %}
        </div>
      {% endif %}
      
      {% if show_button == "true" %}
        <a class="ue-button" href="{{link}}" {{link_html_attributes|ucsafe|raw}}>
          {% if item.button_label is not empty %}{{item.button_label|ucsafe|raw}}{% else %}{{button_label|ucsafe|raw}}{% endif %}
          {% if show_button_icon == "true" %}
            {{button_icon_html|ucsafe|raw}}
          {% endif %}
        </a>
      {% endif %}
      
    </div>
  
</div>