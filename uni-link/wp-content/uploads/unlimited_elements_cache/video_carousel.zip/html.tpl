{% if carousel_type == "owl" %}

	<div id="{{uc_id}}"
         class="ue-video-carousel uc_carousel owl-carousel owl-theme uc-items-wrapper {{remote_parent.class}} {{uc_filtering_addclass}}"
         {% if (debug_hover_state == "true" and uc_inside_editor == "yes") or (autoplay_all_videos == "true") %}data-debug="true"{% endif %}
         data-autoplay-center="{{autoplay_center_video}}"
         data-play-mode="{{play_mode}}"
         data-play-sound="{{enable_sound}}"
         data-close-on-outside-click="{{stop_video_on_outside_click}}"
         {% if show_lightbox == "true" %}data-show-lightbox="true"{% endif %}
         {% if rtl == "true" %}dir="rtl" style="direction:rtl;"{% elseif rtl == "false" %}dir="ltr" style="direction:ltr;"{% endif %} style="direction:{{direction}}"
         {{remote_parent.attributes|raw}} {{uc_filtering_attributes|raw}}
         >
            {{put_items()}}
    </div>	

{% elseif carousel_type == "marquee" %}

    <div id="{{uc_id}}" class="ue-video-carousel uc_logo_marquee {{uc_filtering_addclass}} uc_marquee_{{direction_marquee}}"
         {% if (debug_hover_state == "true" and uc_inside_editor == "yes") or (autoplay_all_videos == "true") %}data-debug="true"{% endif %}
         data-autoplay-center="{{autoplay_center_video}}"
         data-play-mode="{{play_mode}}"
         data-play-sound="{{enable_sound}}"
         data-close-on-outside-click="{{stop_video_on_outside_click}}"
         {% if show_lightbox == "true" %}data-show-lightbox="true"{% endif %}
         {% if rtl == "true" %}dir="rtl" style="direction:rtl;"{% elseif rtl == "false" %}dir="ltr" style="direction:ltr;"{% endif %} style="direction:{{direction}}"
         {{uc_filtering_attributes|raw}}
         >
          <div class="uc_marquee uc-items-wrapper" data-height="{{box_height}}" data-speed="{{transition_speed_marquee}}" data-mobile-items="{{number_of_items_marquee_mobile}}" data-tablet-items="{{number_of_items_marquee_tablet}}" data-desktop-items="{{number_of_items_marquee}}" data-margin="{{margin_between_items_marquee}}" data-paused="{{autoplay_hover_pause_marquee}}" data-direction="{{direction_marquee}}">
            {{put_items()}}
         </div>	
    </div>

    {% if show_lightbox == "true" %}
       <!--- <div id="{{uc_id}}-lightbox" class="ue-htmlvideo-lightbox"></div> --->
    {% endif %}

{% endif %}