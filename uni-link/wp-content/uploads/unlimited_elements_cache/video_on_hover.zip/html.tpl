{# twig vars #}{##}
{% set overlayTextElem %}<span class="ue-overlay-text">{{overlay_text|ucsafe|raw}}</span>{% endset %}
{# end twig vars #}{##}

<div id="{{uc_id}}" class="ue-hover-image-video"
     data-restart="{{restart_video}}"
     {% if debug_hover_state == "true" and (uc_inside_editor == "yes") %}data-debug="true"{% endif %}
     data-mode="{{mode}}"
     data-play-sound="{{enable_sound}}"
     {% if show_lightbox == "true" %}
       data-show-lightbox="true"
       {% if video_source == "html5video" %}
         href="{% if video_url is not empty %}{{video_url}}{% else %}{{uc_assets_url}}/demo-video.mp4{% endif %}"
       {% elseif video_source == "vimeo" %}
         href="https://vimeo.com/{{ vimeo_video_id|ucsafe|raw }}"
       {% endif %}
       data-lity
     {% elseif show_lightbox == "false" and open_link_on_click == "true" %}
       data-enable-link="true"
       data-link="{{data_link}}"
       {{data_link_html_attributes|ucsafe|raw}}
     {% endif %}
     tabindex="0"
     role="button" aria-label="Play video on hover"
     {%  if(uc_inside_editor == "yes") %}data-inside-editor="true"{% endif %}
     >
      <img class="ue-image" src="{{image}}" alt="{{image_alt}}" {{image_attributes|ucsafe|raw}}>
      {% if video_source == "html5video" %}
        <video class="ue-video" preload="metadata" muted playsinline loop>
          <source src="{% if video_url is not empty %}{{video_url}}{% else %}{{uc_assets_url}}/demo-video.mp4{% endif %}" type="video/mp4" />
        </video>
      {% endif %}
      {% if video_source == "vimeo" %}
        <iframe
          class="ue-video"
          src="https://player.vimeo.com/video/{{vimeo_video_id|ucsafe|raw}}?background=1&autoplay=1&muted=1&loop=1&title=0&byline=0&portrait=0"
          frameborder="0"
          allow="autoplay; fullscreen"
          >
        </iframe>
      {% endif %}
      {% if show_overlay == "true" %}
        <div class="ue-overlay">
          {% if show_overlay_icon == "true" %}<span class="ue-overlay-icon" role="img" aria-hidden="true">{{overlay_icon_html|ucsafe|raw}}</span>{% endif %}
          {% if show_overlay_text == "true" %}{{overlayTextElem}}{% endif %}
        </div>
      {% endif %}
      {% if show_button == "true" %}
        <a class="ue-button" href="{{link}}" {{link_html_attributes|ucsafe|raw}}>
          {{button_label|ucsafe|raw}}
          {% if show_button_icon == "true" %}{{button_icon_html|ucsafe|raw}}{% endif %}
        </a>
      {% endif %}
</div>

{% if enable_schema == "true" and video_source == "html5video" %}
  <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "VideoObject",
      "name": "{{video_name|ucsafe|raw}}",
      "description": "{{video_description|ucsafe|raw}}",
      "thumbnailUrl": "{{image}}",
      {% if video_upload_date is not empty %}"uploadDate": "{{video_upload_date|ucsafe|raw}}",{% endif %}
      {% if video_duration is not empty %}"duration": "{{video_duration|ucsafe|raw}}",{% endif %}
      "contentUrl": "{% if video_url is not empty %}{{video_url}}{% else %}{{uc_assets_url}}/demo-video.mp4{% endif %}",
      {% if embed_url is not empty %}"embedUrl": "{{embed_url}}",{% endif %}
      "encodingFormat": "video/mp4",
      "publisher": {
        "@type": "{{publisher}}",
        {% if publisher_name is not empty %}"name": "{{publisher_name|ucsafe|raw}}",{% endif %}
        {% if publisher_url is not empty %}"url": "{{publisher_url}}"{% endif %}
      }
    }
  </script>
{% endif %}