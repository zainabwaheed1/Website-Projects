{{ ucfunc("put_docready_start") }}

  var objWidget = jQuery("#{{uc_id}}");

  UEVideoHoverWidget(objWidget);

{{ ucfunc("put_docready_end") }}