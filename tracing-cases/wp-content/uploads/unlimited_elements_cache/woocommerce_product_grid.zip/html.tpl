<div class="uc_post_grid_style_one woocommerce_product_grid{{uc_filtering_addclass}} {{remote_parent.class}} {{uc_dynamic_popup_class}}" id="{{uc_id}}" {{remote_parent.attributes|raw}} {{uc_filtering_attributes|raw}} style="direction:{{direction}};text-align:{{alignment}};">
  <div class="uc_post_grid_style_one_wrap uc-items-wrapper ue-woo-grid">
    {{put_items()}}
  </div>
</div>


{% if show_empty_message == "true" %}
  <div id="{{uc_id}}_empty_message" class="ue-no-posts-found" {% if uc_num_items > 0 %} style="display:none" {% endif %}>{{no_posts_found|raw}}</div>
{% endif %}