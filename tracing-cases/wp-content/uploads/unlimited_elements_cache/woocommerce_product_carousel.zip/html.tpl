<div class="uc_overlay_image_carousel">
   <div class="uc_carousel owl-carousel owl-theme uc-items-wrapper {{remote_parent.class}} {{uc_filtering_addclass}} {{uc_dynamic_popup_class}}" id="{{uc_id}}" {{remote_parent.attributes|raw}} data-custom-sethtml="true" {{uc_filtering_attributes|raw}}>
   		{{put_items()}}
   </div>	
</div>

{% if show_empty_message == "true" %}

  <div id="{{uc_id}}_empty_message" class="ue-no-posts-found" {% if uc_num_items > 0 %} style="display:none" {% endif %}>{{no_posts_found|raw}}</div>

{% endif %}