{% if item.products.woo_sale_price is empty %}
	#{{item.item_id}} .uc_regular_price:not(.uc_regular_price--single){
      display:none
    }
{% else %} 
	{% if show_sale_price == "true" %}
      {% if item.products.woo_sale_price_from != "" and item.products.woo_sale_price_to != "" %}
        #{{item.item_id}} .uc_regular_price:not(.uc_regular_price--single){
          text-decoration:line-through;
        }
      {% endif %}
	  {% if item.products.woo_sale_price is not empty %}
        #{{item.item_id}} .uc_regular_price:not(.uc_regular_price--single){
          text-decoration:line-through;
        }
      {% endif %}
	{% endif %}
{% endif %}