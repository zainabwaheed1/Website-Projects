<div class="ue-carousel-item ue-grid-item {% if layout == "marquee" %}uc_marquee_holder{% endif %}" data-link="{{item.listing.link}}" data-loop="{{loop}}" data-postid="{{item.listing.id}}">
  {{putListingItemTemplate(item.listing.object,listing_templateid)}}
</div>