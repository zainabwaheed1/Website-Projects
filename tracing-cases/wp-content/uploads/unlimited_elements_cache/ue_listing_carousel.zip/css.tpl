#{{uc_id}} *{
  box-sizing:border-box;
}
#{{uc_id}}{
  display: none;
  position:relative;
  min-height:1px;
}
#{{uc_id}} .owl-item {
  -webkit-backface-visibility: hidden;
  -webkit-transform: translateZ(0) scale(1.0, 1.0);
}

{% if equal_item_height == "true" %}
#{{uc_id}} .owl-stage{
  display: flex;
}  

#{{uc_id}} .owl-item{
  display: flex;
  min-height: 100%;
}  
{% endif %}	

#{{uc_id}} .uc_carousel_item{
  overflow:hidden;
}

{% if layout == "carousel" %}
#{{uc_id}} .owl-nav .owl-prev{
  position:absolute;
  display:inline-block;
  text-align:center;
}

#{{uc_id}} .owl-nav .owl-next{
  position:absolute;
  display:inline-block;
  text-align:center;
}

#{{uc_id}} .owl-dots {
  overflow:hidden;
  text-align:{{dot_alignment}};
}

#{{uc_id}} .owl-dot {
  display:inline-block;
  transition: all .3s;  
}

#{{uc_id}} .owl-nav .owl-prev.disabled,
#{{uc_id}} .owl-nav .owl-next.disabled {
  display: none;
}
{% endif %}

/* Layout type marquee */
{% if layout == "marquee" %}
#{{uc_id}} .uc_marquee {
  display: flex;
  align-items: center;
  overflow: hidden;
  position: relative;
}
#{{uc_id}} .uc_marquee > div {
  position:relative;
  display: inline-flex;
  align-items: center;
  flex: 0 0 auto;
  width: auto;
  overflow: hidden;
  {% if direction == "left" %}
  animation-name: marquee-to-left;
  {% elseif direction == "right" %}
  animation-name: marquee-to-right;
  {% elseif direction == "up" %}
  animation-name: marquee-to-up;
  {% elseif direction == "down" %}
  animation-name: marquee-to-down;
  {% endif %}
  animation-timing-function: linear;
  animation-iteration-count: infinite;
  {% if direction == "up" or direction == "down" %}
  flex-direction: column;
  width: 100%;
  {% endif %}
}

{% if direction == "up" or direction == "down" %}
#{{uc_id}} .uc_marquee_holder{
  width: 100%;
}
{% endif %}

{% if direction == "left" %}
@keyframes marquee-to-left {
  from {transform: translate(0,0)}
  to {transform: translate(-50%,0)}
}
{% endif %}	

{% if direction == "right" %}
@keyframes marquee-to-right {
  from {transform: translate(-50%,0)}
  to {transform: translate(0,0)}
}
{% endif %}

{% if direction == "up" %}
@keyframes marquee-to-up {
  from {transform: translate(0, 25%)}
  to {transform: translate(0, -25%)}
}
{% endif %}

{% if direction == "down" %}
@keyframes marquee-to-down {
  from {transform: translate(0, -25%)}
  to {transform: translate(0, 25%)}
}
{% endif %}

{% endif %}
/* end carousel */