{{ ucfunc("put_docready_start") }}
    
    var objWidget = jQuery('#{{uc_id}}');
    
    //show after js load
    objWidget.show();
    
    {% if layout == "carousel" %}
    
      objWidget.owlCarousel({
        scrollToHead: {{scroll_to_head}},
        scrollToHeadOffset: {{scroll_to_head_offset}},
        rtl:{{rtl}},
        loop: {{loop}},
        navRewind:{{navigation_rewind}},
        center: {{center}},
        autoplayTimeout: {{autoplay_timeout}},
        autoplayHoverPause: {{autoplay_hover_pause}},
        smartSpeed: {{transition_speed}},
        navText: ["<i class='{{left_arrow}}'></i>","<i class='{{right_arrow}}'></i>"],
        setActiveClassOnMobile:{{active_on_mobile}},
        changeItemOnClick:{{scroll_on_click}},					
        nav: {{show_arrows}},
        navigation:true,
        dots: {{show_dots}},                    
        mouseDrag:{{mouse_drag}},
        touchDrag:{{touch_drag}},  
        autoplay: {{autoplay}},        
        preloadHeight: {{show_preload_height}},    
        autoHeight: {{auto_height}},     
        paddingType: "{{stage_padding_type}}", 
        responsive : {
          0 : {
            items:{{number_of_items_mobile}},
			margin: {{margin_between_items_mobile}},
            {% if stage_padding_type != "none" %}
            stagePadding: {{stagepadding_mobile}},
            {% endif %}   
            {% if center == "false" %}
                dotsEach: {{show_dots_each_x_item_mobile}},
            {% endif %}                
          },
          768 : {
            items:{{number_of_items_tablet}},
			margin: {{margin_between_items_tablet}},
            {% if stage_padding_type != "none" %}
            stagePadding: {{stagepadding_tablet}},
            {% endif %}   
            {% if center == "false" %}
              dotsEach: {{show_dots_each_x_item_tablet}},
            {% endif %}                
          },
          980 : {
            items:{{number_of_items}},
			margin: {{margin_between_items}},
            {% if stage_padding_type != "none" %}
            stagePadding: {{stagepadding}},
            {% endif %} 
            {% if center == "false" %} 
              dotsEach: {{show_dots_each_x_item}},
            {% endif %}               
          } 
        }
      });

      {{ucfunc("put_remote_parent_js","objWidget")}}  

      objWidget.on("uc_ajax_sethtml",function(event, htmlItems, isAppend){      
        objWidget.trigger("replace.owl.carousel",htmlItems);
        objWidget.trigger("refresh.owl.carousel");      
      });
    
    {% endif %}
    {% if layout == "marquee" %}
    
      var objMarquee = objWidget.find(".uc_marquee");

      setTimeout(function(){
        UCMarqueeAx(objMarquee);    
      },200);

      objWidget.on("uc_ajax_refreshed",function(){
        UCMarqueeAx(objMarquee);     
      });
    
    {% endif %}
    
{{ ucfunc("put_docready_end") }}