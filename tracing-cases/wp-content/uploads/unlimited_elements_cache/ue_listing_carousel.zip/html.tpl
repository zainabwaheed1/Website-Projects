{% if rtl == "false" %}<div class="ue_listing_carousel"  style="direction:ltr;">{% endif %}
{% if rtl == "true" %}<div class="ue_listing_carousel"  style="direction:rtl;">{% endif %}

  {% if layout == "carousel" %}
    <div class="ue_carousel owl-carousel owl-theme uc-items-wrapper {{remote_parent.class}} {{uc_filtering_addclass}} uc-dynamic-popup-grid" id="{{uc_id}}" {{remote_parent.attributes|raw}} data-custom-sethtml="true" {{uc_filtering_attributes|raw}}>
   	  {{put_items()}}
    </div>
  {% endif %}
  {% if layout == "marquee" %}
    <div class="ue-layout uc_logo_marquee uc_marquee_{{direction_marquee}} {{uc_filtering_addclass}}" id="{{uc_id}}" {{uc_filtering_attributes|raw}}>
      <div class="ue_carousel uc_marquee uc-items-wrapper {{remote_parent.class}}  uc-dynamic-popup-grid" {{remote_parent.attributes|raw}} data-custom-sethtml="true"  data-height="{{item_height_nounit}}" data-height-tab="{{item_height_tablet_nounit}}" data-height-mobile="{{item_height_mobile_nounit}}" data-speed="{{transition_speed_marquee}}" data-mobile-items="{{number_of_items_marquee_mobile}}" data-tablet-items="{{number_of_items_marquee_tablet}}" data-desktop-items="{{number_of_items_marquee}}" data-mobile-margin="{{mq_margin_between_items_mobile}}" data-tablet-margin="{{mq_margin_between_items_tablet}}" data-desktop-margin="{{mq_margin_between_items}}" data-paused="{{autoplay_hover_pause_marquee}}" data-direction="{{direction}}">
   	    {{put_items()}}
      </div>
    </div>
  {% endif %}
</div>